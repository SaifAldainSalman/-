import java.util.Scanner;//الشئ الوحيد الي جبته من تشات هو داله الادخال السكانر وكيف نعملها
class calolater {
    int number1;
    int number2;
    void add (){
        System.out.println("========================");
        System.out.println(" number1 + number2 = "+(number1+number2));
    }
    void sub (){
        System.out.println("========================");
        System.out.println(" number1 - number2 = "+(number1-number2));
    }
    void mul (){
        System.out.println("========================");
        System.out.println(" number1 * number2 = "+(number1*number2));
    }
    void div (){
        System.out.println("========================");
        if (number2!=0)
        System.out.println(" number1 / number2 = "+(number1/number2));
        else System.out.println(" number1 / number 2 = eeror");
    }
    void isequql (){
        System.out.println("========================");
        if (number1==number2)
        System.out.println(" number1 = number2 ? ... TRUE");
        else System.out.println(" number1 = number2 ? ... FALSE");
    }
}

public class Main {
    public static void main (String[] args){
        Scanner input =new Scanner(System.in);
        calolater numbers =new calolater();

        System.out.println(" plaese.. enter nuber 1 : ");
        numbers.number1 = input.nextInt();
        System.out.println(" plaese.. enter number 2 : ");
        numbers.number2 =input.nextInt();

        numbers.add();
        numbers.sub();
        numbers.mul();
        numbers.div();
        numbers.isequql();


    }




}